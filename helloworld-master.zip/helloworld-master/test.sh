echo $HOSTNAME
echo $PWD
echo $SHELL
